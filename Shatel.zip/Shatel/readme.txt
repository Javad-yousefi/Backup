 
this project is not Complete yet 
the ShatelTest is login and register with chosse city and connect to data base
the simple shop is a demo for online shop 
user can access to the shop after register
